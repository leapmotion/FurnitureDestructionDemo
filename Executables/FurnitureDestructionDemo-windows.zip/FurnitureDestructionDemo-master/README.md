FurnitureDestructionDemo
========================

https://developer.leapmotion.com/libraries/303

Walk around house, destroy furniture! 

Supports Oculus Rift 0.4.4

LEAP Motion 2.2.0 + 23475

Mount the LEAP Motion in front of oculus rift.

The program would recognize your hand and allow you to destroy objects that are in front of you.



Movement-wise, best played with Car Controller with acceleration pedal and break pedal.

Acceleration Pedal for moving forward

Break Peal for moving backward.

If there are no access to Car Controller, usual WASD would allow you to move forward and back.



When you are moving back and forth, the rotation of Oculus rift is going to affect the rotation of body.

When you are stationary, the oculus rift rotation is used to look around you just as usual.